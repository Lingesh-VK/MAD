package com.example.gui

import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var collegeNameTextView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        collegeNameTextView = findViewById(R.id.collegeNameTextView)

        // Set initial values
        collegeNameTextView.text = "Rajalakshmi Engineering College"

        // Setup buttons
        setupChangeFontSizeButton()
        setupChangeFontColorButton()
        setupChangeBackgroundColorButton()
    }

    private fun setupChangeFontSizeButton() {
        val button = findViewById<Button>(R.id.changeFontSizeButton)
        val fontSizes = arrayOf(16f, 20f, 24f, 28f, 32f)
        var currentIndex = 0

        button.setOnClickListener {
            currentIndex = (currentIndex + 1) % fontSizes.size
            collegeNameTextView.textSize = fontSizes[currentIndex]
            showToast("Font size changed to ${fontSizes[currentIndex]}sp")
        }
    }

    private fun setupChangeFontColorButton() {
        val button = findViewById<Button>(R.id.changeFontColorButton)
        val colors = arrayOf(
            Color.BLACK,
            Color.RED,
            Color.BLUE,
            Color.GREEN,
            Color.MAGENTA
        )
        val colorNames = arrayOf("Black", "Red", "Blue", "Green", "Magenta")
        var currentIndex = 0

        button.setOnClickListener {
            currentIndex = (currentIndex + 1) % colors.size
            collegeNameTextView.setTextColor(colors[currentIndex])
            showToast("Text color changed to ${colorNames[currentIndex]}")
        }
    }

    private fun setupChangeBackgroundColorButton() {
        val button = findViewById<Button>(R.id.changeBackgroundButton)
        val colors = arrayOf(
            Color.WHITE,
            Color.LTGRAY,
            Color.CYAN,
            Color.YELLOW,
            Color.parseColor("#3F51B5") // Indigo
        )
        val colorNames = arrayOf("White", "Light Gray", "Cyan", "Yellow", "Indigo")
        var currentIndex = 0

        // Get the root layout
        val rootLayout = findViewById<View>(R.id.rootLayout)

        button.setOnClickListener {
            currentIndex = (currentIndex + 1) % colors.size

            // Change the background color of the entire layout
            rootLayout.setBackgroundColor(colors[currentIndex])

            // Change text colors to ensure readability
            if (colors[currentIndex] == Color.YELLOW || colors[currentIndex] == Color.WHITE || colors[currentIndex] == Color.LTGRAY) {
                collegeNameTextView.setTextColor(Color.BLACK)
                findViewById<TextView>(R.id.appTitleTextView).setTextColor(Color.BLACK)
            } else {
                collegeNameTextView.setTextColor(Color.WHITE)
                findViewById<TextView>(R.id.appTitleTextView).setTextColor(Color.WHITE)
            }

            showToast("Background changed to ${colorNames[currentIndex]}")
        }
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}

